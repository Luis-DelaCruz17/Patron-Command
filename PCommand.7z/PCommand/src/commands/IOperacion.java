package commands;

//Command ---- java8
@FunctionalInterface
public interface IOperacion {
    
    void execute();
}
